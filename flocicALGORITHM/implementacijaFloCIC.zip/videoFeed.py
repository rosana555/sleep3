import os
import cv2
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import paho.mqtt.client as mqtt
import subprocess


broker = "10.241.227.26"
port = 1883
topic = "/input"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FLOCIC_EXE = os.path.abspath(os.path.join(BASE_DIR, "..", "floCIC", "cmake-build-mscv","floCIC.exe"))



def flocic_compress_gray(gray: "np.ndarray") -> bytes:
    # gray must be HxW uint8
    h, w = gray.shape[:2]
    raw = gray.tobytes()

    p = subprocess.Popen(
        [FLOCIC_EXE, "--compress", str(w), str(h)],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )

    out, err = p.communicate(input=raw)

    if p.returncode != 0:
        raise RuntimeError(f"flocic failed rc={p.returncode}: {err.decode('utf-8', errors='replace')}")

    return out



def init_mqtt(producer):
    try:
        producer.connect(broker, port, 5)  # Shorter timeout
    except Exception as e:
        print(f"[MQTT Init] Failed to connect: {e}")

def on_connect(client, userdata, flags, reasonCode, properties=None):
  print("Povezava z MQTT: " + str(reasonCode))




class VideoFeed:
    def __init__(self, master, producer):
        self.master = master
        self.master.title("Live Video Feed Simulator")
        self.master.geometry("500x500")
        self.master.resizable(False, False)
        self.master.protocol("WM_DELETE_WINDOW", self.on_close)
        self.producer = producer

        # Container frame to center content
        container = ttk.Frame(master)
        container.place(relx=0.5, rely=0.5, anchor="center")

        # Grid layout within container
        container.columnconfigure(0, weight=1)

        ttk.Button(container, text="Select Video", command=self.select_video).grid(row=0, column=0, pady=5, sticky="ew")
        ttk.Button(container, text="Use Camera Feed", command=self.use_camera_feed).grid(row=1, column=0, pady=5, sticky="ew")

        self.lbl_path = ttk.Label(container, text="No video selected")
        self.lbl_path.grid(row=2, column=0, sticky="ew")

        ttk.Label(container, text="Frames per second (fps):").grid(row=3, column=0, sticky="w", pady=(10, 0))
        self.fps_entry = ttk.Entry(container, justify="center")
        self.fps_entry.insert(0, "5")
        self.fps_entry.grid(row=4, column=0, sticky="ew")

        ttk.Button(container, text="Start Stream", command=self.start_stream).grid(row=5, column=0, pady=10, sticky="ew")

        self.video_path = None
        self.use_camera = False

    def select_video(self):
        path = filedialog.askopenfilename(filetypes=[("Video files", "*.mp4 *.avi *.mov *.mkv")])
        if path:
            self.video_path = path
            self.use_camera = False
            self.lbl_path.config(text=os.path.basename(path))

    def use_camera_feed(self):
        self.video_path = None
        self.use_camera = True
        self.lbl_path.config(text="Using live camera feed")

    def start_stream(self):
        try:
            fps_target = float(self.fps_entry.get())
            if fps_target <= 0:
                raise ValueError("FPS must be positive.")
        except ValueError as e:
            messagebox.showerror("Invalid FPS", str(e))
            return

        delay = 1.0 / fps_target

        if self.use_camera:
            cap = cv2.VideoCapture(0)
        else:
            if not self.video_path:
                messagebox.showerror("Error", "No video or camera selected.")
                return
            cap = cv2.VideoCapture(self.video_path)

        if not cap.isOpened():
            messagebox.showerror("Error", "Failed to open video source.")
            return

        frame_num = 0

        def stream_loop():
            nonlocal frame_num
            ret, frame = cap.read()
            if not ret:
                cap.release()
                messagebox.showinfo("Done", f"Streamed {frame_num} frames.")
                self.send_frame_to_server(0, 0)
                return

            self.send_frame_to_server(frame_num, frame)
            frame_num += 1
            self.master.after(int(delay * 1000), stream_loop)

        self.use_camera = False  # Reset after use
        stream_loop()

    def send_frame_to_server(self, frame_num, frame):
        if isinstance(frame, int):
            payload = str(frame).encode("ascii")  # b"0", b"-1"
            ret = self.producer.publish(topic, payload, qos=1, retain=False)
            print(f"Sent CTRL {frame} rc={ret.rc}")
            print(f"Pošiljanje: sporočilo o koncu, rc={ret.rc}, topic: {topic}")
            return

        # 1) Encode to BMP
        #success, buffer = cv2.imencode('.jpg', frame)
        #success, buffer = cv2.imencode('.bmp', frame)
        # if not success:
        #     print(f"Failed to encode frame {frame_num}")
        #     return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        try:
            payload = flocic_compress_gray(gray)
        except Exception as e:
            print(f"Compression failed on frame {frame_num}: {e}")
            return

        # 2) Convert to bytes
        #payload = buffer.tobytes()

        # 3) Publish the bytes
        ret = self.producer.publish(topic, payload, qos=1, retain=False)

        # 4) Log
        print(f"Pošiljanje: frame {frame_num}  rc={ret.rc}, topic: {topic}")

    def on_close(self):
        print("Window is closing.")
        self.master.destroy()

def main(test_mode=False):
    if test_mode:
        print("Running in test mode.")
        return
    else:
        producer = mqtt.Client(client_id="videoFeed", callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
        producer.max_inflight_messages_set(100000)
        init_mqtt(producer)  # 40 minutes
        producer.on_connect = on_connect
        producer.loop_start()

        root = tk.Tk()
        app = VideoFeed(root, producer)
        root.mainloop()

if __name__ == '__main__':
    main()
